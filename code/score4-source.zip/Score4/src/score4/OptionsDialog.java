package score4;

import javax.swing.*;
import javax.swing.event.*;

import java.awt.*;
import java.awt.event.*;

/**
 * <p>Title: Score4</p>
 * <p>Description: Game</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Home</p>
 * @author Panagiotis Bouros & Nick Konstantinou
 * @version 1.1
 */

public class OptionsDialog extends JDialog implements ActionListener {
  public boolean onOk = false;			//Event clicked Ok button
  public boolean bSingleGame = false;		//false:	Human vs Human
                                                //true :	Human vs CPU

  //Buttons
  private JButton btOk = new JButton("OK");
  private JButton btCancel = new JButton("Cancel");

  //Type of game options - Number of players
  private JRadioButton rbtTwoPlayersGame = new JRadioButton("Human vs Human", true);
  private JRadioButton rbtOnePlayerGame = new JRadioButton("Human vs CPU", false);
  private ButtonGroup bgrpRadioPlayers = new ButtonGroup();

  //Panel
  private JPanel panel = new JPanel(null);

  /**
   * Constructor
   * @param frOwner JFrame owner of the OptionsDialog
   * @param bSingleG Is single game
   */
  public OptionsDialog(JFrame frOwner, boolean bSingleG) {
    super(frOwner, true);
    setTitle("Score 4 Options");
    setSize(272, 142);
    setResizable(false);

    Point p = frOwner.getLocationOnScreen();
    Double x = new Double(p.getX());
    Double y = new Double(p.getY());
    int i = x.intValue() + 39;
    setLocation(new Point(x.intValue() + 39, y.intValue() + 89));

    bSingleGame = bSingleG;

    //Radio buttons
    rbtOnePlayerGame.setBounds(new Rectangle(18, 7, 164, 23));
    rbtTwoPlayersGame.setBounds(new Rectangle(18, 30, 164, 33));
    rbtTwoPlayersGame.addActionListener(this);
    rbtOnePlayerGame.addActionListener(this);
    bgrpRadioPlayers.add(rbtTwoPlayersGame);
    bgrpRadioPlayers.add(rbtOnePlayerGame);
    panel.add(rbtTwoPlayersGame, null);
    panel.add(rbtOnePlayerGame, null);
    if (bSingleGame)
      bgrpRadioPlayers.setSelected(rbtOnePlayerGame.getModel(), true);

    //Buttons
    btOk.setBounds(new Rectangle(54, 71, 74, 25));
    btCancel.setBounds(new Rectangle(134, 71, 74, 25));
    btOk.setMnemonic('O');
    btCancel.setMnemonic('C');
    btOk.addActionListener(this);
    btCancel.addActionListener(this);
    panel.add(btOk, null);
    panel.add(btCancel, null);

    this.getContentPane().add(panel, BorderLayout.CENTER);
  } //End Constructor OptionsDialog


  /**
   * Action handlerer
   * @param e Action event
   */
  public void actionPerformed(ActionEvent e) {
    //Action = Button Click///////
    if (e.getSource() == btOk) {
      onOk = true;
      dispose();
    }
    if (e.getSource() == btCancel)
      dispose();
    //////////////////////////////

    //Action = Radio Click//////////////////////////////////////////////////
    //Game type ?
    //Human vs Human Or Human vs CPU
    if ((e.getSource() == rbtTwoPlayersGame) ||
        (e.getSource() == rbtOnePlayerGame)) {
      if (bgrpRadioPlayers.getSelection() == rbtTwoPlayersGame.getModel())
        bSingleGame = false;
      else
        bSingleGame = true;
    }
  ////////////////////////////////////////////////////////////////////////
  } //End actionPerformed

} //End class OptionsDialog