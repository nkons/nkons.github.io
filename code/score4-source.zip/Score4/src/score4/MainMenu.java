package score4;

import javax.swing.*;
import javax.swing.event.*;

import java.awt.*;
import java.awt.event.*;

/**
 * <p>Title: Score4</p>
 * <p>Description: Game</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Home</p>
 * @author Panagiotis Bouros & Nick Konstantinou
 * @version 1.1
 */

public class MainMenu extends JMenuBar {
  //Menu items and sub-menus
  public JMenu menuGame = new JMenu("Game");
  public JMenu menuHelp = new JMenu("Help");
  public JMenuItem gameNew = new JMenuItem("New...");
  public JMenuItem gameOptions = new JMenuItem("Options...");
  public JMenuItem gameExit = new JMenuItem("Exit");
  public JMenuItem helpAbout = new JMenuItem("About...");

  /**
   * Constructor
   */
  public MainMenu() {
    //Game Menu
    menuGame.setMnemonic('G');
    gameNew.setMnemonic('N');
    gameNew.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, KeyEvent.CTRL_MASK));
    menuGame.add(gameNew);
    gameOptions.setMnemonic('O');
    gameOptions.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, KeyEvent.CTRL_MASK));
    menuGame.add(gameOptions);
    menuGame.addSeparator();
    gameExit.setMnemonic('X');
    gameExit.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X, KeyEvent.CTRL_MASK));
    menuGame.add(gameExit);
    add(menuGame);


    //Help Menu
    menuHelp.setMnemonic('H');
    helpAbout.setMnemonic('A');
    helpAbout.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A, KeyEvent.CTRL_MASK));
    menuHelp.add(helpAbout);
    add(menuHelp);
  } //End of Constructor


  /**
   * Adding Action Listeners for the menu options
   * @param listener Action listener
   */
  public void addActionListener(ActionListener listener) {
    gameNew.addActionListener(listener);
    gameOptions.addActionListener(listener);
    gameExit.addActionListener(listener);
    helpAbout.addActionListener(listener);
  } //End addActionListener

}
