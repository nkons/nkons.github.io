package score4;

import javax.swing.*;
import javax.swing.event.*;

import java.awt.*;
import java.awt.event.*;

/**
 * <p>Title: Score4</p>
 * <p>Description: Game</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Home</p>
 * @author Panagiotis Bouros & Nick Konstantinou
 * @version 1.1
 */

public class TableOfMoves extends JPanel implements MouseListener {
  private Score4 frOwner = null;

  //Table graphical and operational
  private  JLabel[][] labelIconTableOfMoves;
  private  int[][] TableOfMoves;

  //Who's turn is
  private  int intPlayerTurn;

  //Score statistics
  int yellowWins = 0, redWins = 0, ties = 0;

  //Players tile standards
  private final  int[] tile = {1, 10, 0};
  private final int TILE_P0 =     0;
  private final int TILE_P1 =     1;
  private final int TILE_CLEAR =  2;
  private final int TILE_P0_WIN = 3;
  private final int TILE_P1_WIN = 4;

  private ImageIcon[] playerIcon;
  int iconWidth = 0;

  //Table dimensions
  private int TableX = 350;
  private int TableY = 300;
  private int XMAX = 6;
  private int YMAX = 7;

  private final int PLAYERWON = 5;
  private final int TABLEFULL = 6;

  boolean bSingleGame = true;
  boolean bPlayerScored;


  /**
   * Constructor
   * @param owner JFrame owner of TableOfMOves panel
   * @param bSingleG Is a single game or not
   */
  public TableOfMoves(Score4 owner, boolean bSingleG) {
    frOwner = owner;
    //Game type
    bSingleGame = bSingleG;

    playerIcon = new ImageIcon[5];
    playerIcon[TILE_P0] = new ImageIcon("resources/red.gif");
    playerIcon[TILE_P1] = new ImageIcon("resources/yellow.gif");
    playerIcon[TILE_CLEAR] = new ImageIcon("resources/blank.gif");
    playerIcon[TILE_P0_WIN] = new ImageIcon("resources/redwin.gif");
    playerIcon[TILE_P1_WIN] = new ImageIcon("resources/yellowwin.gif");

    setBackground(new Color(7,10,149));

    iconWidth = TableX / YMAX;
    labelIconTableOfMoves = new JLabel[XMAX][YMAX];
    TableOfMoves = new int[XMAX][YMAX];

    setLayout(new GridLayout(XMAX,YMAX));

    setSize(TableX,TableY);
    addMouseListener(this);

    //Initialization of Table
    for (int i = 0; i < XMAX; i++) {
      for (int j = 0; j < YMAX; j++) {
        labelIconTableOfMoves[i][j] = new JLabel(playerIcon[2]);
        add(labelIconTableOfMoves[i][j]);
        TableOfMoves[i][j] = 0;
      } //End for (int j = 0; j < YMAX; j++)
    } //End for (int i = 0; i < XMAX; i++)

    intPlayerTurn = 1;
    bPlayerScored = false;
  } //End constructor TableOfMoves


  /////////////////////////////////////////////////////
  //MOUSE EVENTS///////////////////////////////////////
  /**
   * Event click at a column
   * @param e Mouse event
   */
  public void mouseClicked(MouseEvent e) {
    int intColumnClicked = e.getX() / iconWidth;

    int p = 0;
    if (!isColumnFull(intColumnClicked))
      p = playerMove(intColumnClicked);

    if ((p == TABLEFULL) || (p == PLAYERWON)) {
      frOwner.tfScore.setText("Yellow wins: " + yellowWins + "\tRed wins: " + redWins + "\tTies: " + ties);
      clearData(bSingleGame);
    }
  }


  public void mousePressed(MouseEvent e) {
  }


  public void mouseReleased(MouseEvent e) {
  }


  public void mouseEntered(MouseEvent e) {
  }


  public void mouseExited(MouseEvent e) {
  }
  //End MOUSE EVENTS///////////////////////////////////

  ////////////////////////////////////////////////////////////////////////
  ///GAME FUNCTIONS///////////////////////////////////////////////////////
  /**
   * Defines whether a column is full
   * @param iColumn The column to be examined
   * @return The column is full or not
   */
  public boolean isColumnFull(int intColumn) {
    return (TableOfMoves[0][intColumn] != 0);
  } //End isColumnFull


  /**
   * Defines whether the table is full
   * @return Is full or not
   */
  public boolean isTableFull() {
    for (int i = 0; i < XMAX; i++)
      for (int j = 0; j < YMAX; j++)
        if (TableOfMoves[i][j] == 0)
          return false;

    return true;
  } //End isTableFull


  /**
   * Change turn of playing
   */
  public void changePlayerTurn() {
    if (intPlayerTurn == 1)
      intPlayerTurn = 0;
    else
      intPlayerTurn = 1;
  } //End changePlayerTurn


  /**
   * At the specific column which the first available line from top to bottom
   * @param intColumn The column to be examined
   * @return The line index
   */
  public int findAvailableLine(int intColumn) {
    int j = 0;
    while ((j < XMAX) && (TableOfMoves[j][intColumn] == 0))
      j++;

    return --j;
  } //End findAvailableLine


  /**
   * Change tile on the table - Deciding result
   * @param i The x position
   * @param j The y position
   * @param pStyle
   * @return
   */
  public int updateTile(int i, int j, int pStyle) {
    //Change table (operational - graphical)
    TableOfMoves[i][j] = tile[pStyle];
    labelIconTableOfMoves[i][j].setIcon(playerIcon[pStyle]);

    //Not evaluating, checking for winner now
    evaluate(false);

    //A player won
    if (bPlayerScored) {
      String strMessage = new String();
      if (bSingleGame)
        if (pStyle == 1) {
          strMessage = "You Win!";
          yellowWins++;
        }
        else {
          strMessage = "I Win!";
          redWins++;
        }
      else
      if (pStyle == 1) {
        strMessage = "Yellow Player Wins!";
        yellowWins++;
      }
      else {
        strMessage = "Red Player Wins!";
        redWins++;
      }

      //Message Box with one button OK and a specific message
      JOptionPane.showMessageDialog(frOwner, strMessage, "Score 4", JOptionPane.INFORMATION_MESSAGE);

      return PLAYERWON;
    }

    //Draw
    if (isTableFull()) {
      ties++;
      JOptionPane.showMessageDialog(frOwner, "It's tie!", "Score 4", JOptionPane.INFORMATION_MESSAGE);

      return TABLEFULL;
    }

//    frOwner.tfScore.setText("Yellow wins: " + yellowWins + "\tRed wins: " + redWins + "\tTies: " + ties);

    return 0;
  } //End updateTile


  /**
   * Player or CPU move - returns result
   * @param intColumn The move
   * @return The result
   */
  public int playerMove(int intColumn) {
    int intMoveResult = 0;

    //Update table - player move
    intMoveResult = updateTile(findAvailableLine(intColumn), intColumn, intPlayerTurn);

    if ((intMoveResult == PLAYERWON) || (intMoveResult == TABLEFULL))
      return intMoveResult;

    changePlayerTurn();

    //Now is CPU turn to play
    if (bSingleGame) {
      int c = CPUMove();

      intMoveResult = updateTile(findAvailableLine(c), c, intPlayerTurn);
      changePlayerTurn();
    }

    return intMoveResult;
  } //End playerMove


  /**
   * Re-initialization - New Game
   * @param bSingleG Is single game
   */
  public void clearData(boolean bSingleG) {
    for (int i = 0; i < XMAX; i++)
      for (int j = 0; j < YMAX; j++) {
        labelIconTableOfMoves[i][j].setIcon(playerIcon[2]);
        TableOfMoves[i][j] = tile[2];
      }

    bPlayerScored = false;
    intPlayerTurn = 1;
    bSingleGame = bSingleG;
  } //End clearData

  //////////////////////////////////AI SECTION////////////////////////////////
  /**
   * CPU player move
   * @return CPU column move
   */
  public int CPUMove() {
    //Make Available Moves Table for the CPU
    int[] intAvail;
    intAvail = new int[YMAX];
    for(int i = 0; i < YMAX; i++)
      intAvail[i] = 0;

    //The number of the moves Available for the CPU
    int intMovesAvail = 0;

    //Calculate the moves available
    for(int j = 0; j < YMAX; j++) {
      if (!isColumnFull(j))
        intAvail[intMovesAvail++] = j;
    }

    //Make Score Table and set it to Zero
    int intScore[];
    intScore = new int[YMAX];
    for(int i = 0; i < YMAX; i++)
      intScore[i] = 0;

    int j1 = 0;
    while (j1 < intMovesAvail) {
      //For each available move, we fill the tile in the table...
      TableOfMoves[findAvailableLine(intAvail[j1])][intAvail[j1]] = tile[intPlayerTurn]; //1st
      //And evaluate the table
      intScore[j1] = evaluate(true);

      //Then, we check all the moves that the human will be able to play
      //Change player turn and test one by one the possible moves
      changePlayerTurn();

      //Make Other Player's Available Moves Table
      int[] intOtherAvail;
      intOtherAvail = new int[YMAX];
      for (int i = 0; i < YMAX; i++)
        intOtherAvail[i] = 0;

      int intOtherMovesAvail = 0;
      for(int j = 0; j < YMAX; j++) {
        if (!isColumnFull(j))
          intOtherAvail[intOtherMovesAvail++] = j;
      }
      //Make Other Player's score table
      int[] intOtherScore;
      intOtherScore = new int[YMAX];
      for(int i = 0; i < YMAX; i++)
        intOtherScore[i] = 0;

      int j2 = 0;
      while(j2 < intOtherMovesAvail) {
        TableOfMoves[findAvailableLine(intOtherAvail[j2])][intOtherAvail[j2]] = tile[intPlayerTurn]; //1st
        //Evalute all possible moves
        intOtherScore[j2] = evaluate(true);
        TableOfMoves[findAvailableLine(intOtherAvail[j2])+1][intOtherAvail[j2]] = 0; //2nd
        j2++;
      }

      //Saving best score - best moves
      int intOtherBestScore = intOtherScore[0];

      for (int k = 0; k < intOtherMovesAvail; k++) {
        int iOtherCheckScore = intOtherScore[k];
        if (iOtherCheckScore >= intOtherBestScore)
          intOtherBestScore = iOtherCheckScore;
      }


      //The CPU move score is CPU move score minus Human player best move score
      //(Min-Max)
      intScore[j1] -= intOtherBestScore;

      changePlayerTurn();
      TableOfMoves[findAvailableLine(intAvail[j1])+1][intAvail[j1]] = 0; //2nd
      j1++;
    }

    //Bubble Sort for CPU moves in order to pick the best (having highest score)
    for (int i = 0; i <= intMovesAvail; i++)
      for (int j = intMovesAvail - 2; j >= i; j--)
        if (intScore[j] < intScore[j + 1]) {
          int temp;

          temp = intScore[j+1];
          intScore[j+1] = intScore[j];
          intScore[j] = temp;
          temp = intAvail[j+1];
          intAvail[j+1] = intAvail[j];
          intAvail[j] = temp;
        } //End if

    //When moves score are the same we pick one using random function
    int intSame = 0;
    while ((intSame < intMovesAvail-1) && (intScore[intSame+1] == intScore[intSame]))
      intSame++;

    double l = (intSame + 0.5) * Math.random();
    int intChoice = Math.round((int)l);

    int intBestMove = intAvail[intChoice];
    int intBestScore = intScore[0];

    return intBestMove;
  } //End CPUMove


  /**
   * Evaluate four item groups from i to j vertically, horozontally and diagonally
   * @param i
   * @param j
   * @param style
   * @param bCPUTest
   * @return
   */
  public int makeScore4(int i, int j, int style, boolean bCPUTest) {
    int intSum = 0;
    int intStepx = 0;
    int intStepy = 0;

    switch(style) {
        case 0: intStepx = 1; intStepy = 0;  break; //vertical
        case 1: intStepx = 0; intStepy = 1;  break; //horizontal
        case 2: intStepx = 1; intStepy = 1;  break; //diagonal \
        case 3: intStepx = -1; intStepy = 1; break; //diagonal /
    }

    for (int times = 0; times < 4; times++)
      intSum += TableOfMoves[i + (intStepx*times)][j + (intStepy*times)];

    int intOtherPlayer;

    if (intPlayerTurn == 0)
      intOtherPlayer = 1;
    else
      intOtherPlayer = 0;

    //Evaluating state
    if (intSum ==     tile[intPlayerTurn] + 3 * tile[intOtherPlayer])
      return 35;
    if (intSum == 2 * tile[intPlayerTurn] + 2 * tile[intOtherPlayer])
      return 4;
    if (intSum == 3 * tile[intPlayerTurn])
      return  42;

    //Winning group of four
    if (intSum == 4 * tile[intPlayerTurn]) {
      if (!bCPUTest) {
        bPlayerScored = true;

        if(intPlayerTurn == 0) {
          for (int t = 0; t < 4; t++)
            labelIconTableOfMoves[i + (t*intStepx)][j + (t*intStepy)].setIcon(playerIcon[TILE_P0_WIN]);
        }
        else {
          for (int t = 0; t < 4; t++)
            labelIconTableOfMoves[i + (t*intStepx)][j + (t*intStepy)].setIcon(playerIcon[TILE_P1_WIN]);
        }
      }

      return 5000;
    } //End if

    //Other player's winning group of four
    if (intSum == 4 * tile[intOtherPlayer]) {
      return -1000;
    } //End if

    return 0;
  } //End makeScore4


  /**
   * Evaluation of table using makeScore4 function
   * @param test Real move or a test move
   * @return
   */
  public int evaluate(boolean test) {
    int i, j;
    int intSum = 0;

    //Vertical check
    for (j = 0; j < YMAX; j++)
      for (i = 0; i < XMAX - 3; i++)
        intSum += makeScore4(i, j, 0,test);

    //Horizontal check
    for (i = 0; i < XMAX; i++)
      for (j = 0; j < YMAX - 3; j++)
        intSum += makeScore4(i, j, 1, test);

    //Diagonal \
    for (i = 0; i < XMAX-3; i++)
      for (j = 0; j < YMAX-3; j++)
        intSum += makeScore4(i, j, 2, test);

    //Diagonal /
    for (i = XMAX-1; i > 2; i--)
      for (j = 0; j < YMAX-3; j++)
        intSum += makeScore4(i, j, 3, test);

    if (bPlayerScored)
      return -1;

    return intSum;
  } //End evaluate

} //End class TableOfMoves
