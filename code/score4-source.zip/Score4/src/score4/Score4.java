package score4;

import java.util.*;

//Graphics
import javax.swing.*;
import javax.swing.event.*;

import java.awt.*;
import java.awt.event.*;


/**
 * <p>Title: Score4</p>
 * <p>Description: Game</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Home</p>
 * @author Panagiotis Bouros & Nick Konstantinou
 * @version 1.1
 */

public class Score4 extends JFrame implements ActionListener {

  //Message Box buttons standards
  final int YES_NO = 0;
  final int OK = 1;
  boolean bSingleGame = true;		//false:	Human vs Human
                                        //true :	Human vs CPU

  //Score statistics
  static JTextField tfScore = new JTextField("Yellow wins: 0\tRed wins: 0\tTies: 0");

  MainMenu mainMenu = new MainMenu();
  TableOfMoves panelTableOfMoves = new TableOfMoves(this, bSingleGame);



  /**
   * Constructor
   */
  public Score4() {
    super("Score 4");
    this.setIconImage((new ImageIcon("resources/16x16icon.gif")).getImage());

    //Adding menu
    setJMenuBar(mainMenu);

    tfScore.setEditable(false);
    getContentPane().add(panelTableOfMoves);
    getContentPane().add(tfScore, BorderLayout.SOUTH);

    //Adding action listener to the menu
    mainMenu.addActionListener(this);

    setSize(350, 320);
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    this.setLocation(Math.max(0, (screenSize.width - 350) / 2),
                     Math.max(0, (screenSize.height - 320) / 2));
    setVisible(true);
    setResizable(false);

    //In order to terminate the utility
    addWindowListener (
        new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    }
    );
  } //End of constructor


  /**
   * Menu Action handlerer
   * @param e Action event
   */
  public void actionPerformed(ActionEvent e) {
    //Menu actions
    JMenuItem itemClicked = (JMenuItem)e.getSource();

    //New game
    if (itemClicked == mainMenu.gameNew) {
      //Constructing a message box with two buttons YES
      //and NO and specified title and message
      int confirm = JOptionPane.showOptionDialog(this, "Start a new game ?", "Score 4", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, null);
      //If the player decidied to start a new game
      //if (dlg.onOk)
      if (confirm == 0)
        panelTableOfMoves.clearData(bSingleGame);
    }

    //Game options
    if (itemClicked == mainMenu.gameOptions) {
      int result = 0;
      JRadioButton rbtTwoPlayersGame = new JRadioButton("Human vs Human", true);
      JRadioButton rbtOnePlayerGame = new JRadioButton("Human vs CPU", false);
      ButtonGroup bgrpRadioPlayers = new ButtonGroup();

      bgrpRadioPlayers.add(rbtOnePlayerGame);
      bgrpRadioPlayers.add(rbtTwoPlayersGame);

      if (bSingleGame)
        rbtOnePlayerGame.setSelected(true);
      else
        rbtTwoPlayersGame.setSelected(true);

      Object[] message = new Object[3];
      message[0] = new String("Select game type:");
      message[1] = rbtOnePlayerGame;
      message[2] = rbtTwoPlayersGame;

      Object[] option = {"OK", "Cancel"};
      result = JOptionPane.showOptionDialog(this, message, "Score 4 Options", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, option, option[0]);

      if (result == 0) {
        bSingleGame = (rbtOnePlayerGame.isSelected() == true);
        panelTableOfMoves.clearData(bSingleGame);
      }
      //JOptionPane.showOptionDialog(this, "Start a new game ?", "Score 4", JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, null);
    }

    //Game exit
    if (itemClicked == mainMenu.gameExit)
      System.exit(0);

      //Help About
    if (itemClicked == mainMenu.helpAbout) {
      JOptionPane.showMessageDialog(this, "Score4 version1.1\n\nPanagiotis Bouros  &  Nick Constantinou\nCopyright 2005", "Score 4", JOptionPane.INFORMATION_MESSAGE, new ImageIcon("resources/32x32icon.gif"));
    }
  } //End of actionPerformed


  /**
   * Main function
   * @param args
   */
  public static void main(String args[]) {
    //Utility object
    Score4 client = new Score4();
  } //End main

} //End Score4 class
