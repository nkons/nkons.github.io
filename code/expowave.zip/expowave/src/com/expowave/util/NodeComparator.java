package com.expowave.util;

import com.expowave.graph.Node;
import java.util.Comparator;

public class NodeComparator implements Comparator<Node> {

    private String order = new String();

    public NodeComparator(String order) {
        setOrder(order);
    }

    //We need reverse order!
    public int compare(Node node1, Node node2) {
        int id1 = node1.getId();
        int id2 = node2.getId();

        Boolean condition = getOrder().equals("ASC") ? id1 > id2 : id1 < id2;

        //inverted 1 and -1
        if (condition) {
            return -1;
        } else if (!condition) {
            return 1;
        } else {
            return 0;
        }
    }

    public String getOrder() {
        return order;
    }

    public void setOrder(String order) {
        this.order = order;
    }
}
