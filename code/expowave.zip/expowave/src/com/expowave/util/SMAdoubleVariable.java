package com.expowave.util;

import java.text.DecimalFormat;
import java.util.ArrayDeque;

public class SMAdoubleVariable {

    private double currSum;
    private int windowSize;
    private double firstMeasurement;
    private ArrayDeque<Double> measurements;
    DecimalFormat df = new DecimalFormat("####.###");

    public SMAdoubleVariable(int windowSize) {
        this.measurements = new ArrayDeque<Double>(windowSize);
        this.windowSize = windowSize;
    }

    public void addMeasurement(double measurement) {
        currSum += measurement;
        measurements.add(measurement);
        if (measurements.size() > windowSize) {
            firstMeasurement = measurements.poll();
            currSum = currSum - firstMeasurement;
        }
    }

    public void clear() {
        this.measurements.clear();
        this.currSum = 0;
    }

    public double getMean() {
        if (measurements.isEmpty()) {
            return 0;
        } else {
            return (double) currSum / measurements.size();
        }
    }

    public double getSum() {
        return (double) currSum;
    }

    public int getSize() {
        return this.measurements.size();
    }

    public String toString() {
        return df.format(this.getMean());
    }
}
