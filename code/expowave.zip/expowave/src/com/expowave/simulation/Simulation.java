package com.expowave.simulation;

import com.expowave.graph.Node;
import com.expowave.graph.Graph;
import com.expowave.util.NodeComparator;
import com.expowave.util.SMAdoubleVariable;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;

public class Simulation {

    //Colorwave = VDCS: Variable-Maximum Distributed Color Selection
    //If two readers connected with an edge transmit at the same time, they collide

    //A color is a periodic reservation for collision-free transmission of data
    //Also: optimize the graph to the smallest number of total colors needed
    //Measure: percentage of successful transmissions
    public boolean verbose = true;
    public boolean measurements = false;
    int maxColors = 0; //no need to modify it here, we read it from a node
    public int successes = 0;
    public int attempts = 0;
    public int collisions = 0;
    public DecimalFormat df = new DecimalFormat("####.###");
    SMAdoubleVariable meanAttempts;
    SMAdoubleVariable meanSuccesses;
    SMAdoubleVariable meanCollisions;
    SMAdoubleVariable meanColors;
    SMAdoubleVariable meanNeighbors;
    SMAdoubleVariable meanThroughput;
    SMAdoubleVariable meanDelay;
    Double successOverAttempt;
    Double collisionPercentage;
    Double S2;

    static boolean nodeWise = false; //Not conducted in the paper
    static boolean graphWise = true;
    static boolean meanIterationWise = false;

    public static final int DCS = 101;
    public static final int COLORWAVE = 102;
    public static final int EXPOWAVE = 103;
    
    public Simulation(String graphFilename, int timeSlots, int maxColors, double sigma, int minTimeInMaxColors, int algorithm, String fileName) {
		PrintStream out1 = null;

		if (fileName != null) {
	        File f1 = new File(fileName);
			try {
	            if (!f1.exists()) f1.createNewFile();
				out1 = new PrintStream(new BufferedOutputStream(new FileOutputStream(f1.getAbsolutePath())));
			} catch (IOException e) {
				e.printStackTrace();
			}
		} else {
			out1 = System.out;
		}
		
        if (nodeWise && out1 != System.out) {
            out1.println("timeSlotId,maxColors,countNeighbors,successOverAttempt,collisionsOverAttempts,meanThroughput,meanDelay");
        }
        if (graphWise && out1 != System.out) {
            out1.println("timeSlotId,meanColors,meanNeighbors,successOverAttempt,collisionPercentage,Throughput(S2),meanDelay");
        }
        if (meanIterationWise && out1 != System.out) {
            out1.println("sigma,meanColors,meanNeighbors,successOverAttempt,collisionPercentage,Throughput(S2),meanDelay");
        }
        
        //Read the Adjacency Matrix
        Graph graph = createGraph(graphFilename, maxColors, sigma, minTimeInMaxColors, algorithm);

        //run simulation for a number of times
        int timeSlotId = 0;
        //if (verbose) System.out.println("timeSlotId \t ");
        for (timeSlotId = 0; timeSlotId < timeSlots; timeSlotId++) {

            //if (verbose) System.out.println(timeSlotId);

            //Clear from previous state the ones that transmitted
            for (Node node : graph.getNodes()) {
                if (node.getStatus() == node.TRANSMITTING) {
                    node.setStatus(node.IDLE);
                }
            }

            Collections.shuffle(graph.getNodes());

            for (Node node : graph.getNodes()) {
                //increase it in every timeslot: only when the color changes it becomes 0
                node.setTimeInMaxColors(node.getTimeInMaxColors() + 1);

                //also set that no changes to Max Colors are done for this timeslot
                node.setChangedMaxColors(false);

                double d = Math.random();
                if (d < node.getSigma()) {
                    node.requestTransmission(timeSlotId);
                } else {
                    node.setStatus(node.IDLE);
                    node.setWaiting(-1); //Need to count how many timeslots will each tag wait before being recognized. -1 serves as the initial size
                    node.getSmaAttempts().addMeasurement(0);
                    node.getSmaDelay().addMeasurement(0);
                }
            }

            //createOverallStatistics
            meanAttempts = new SMAdoubleVariable(graph.getNodes().size());
            meanSuccesses = new SMAdoubleVariable(graph.getNodes().size());
            meanCollisions = new SMAdoubleVariable(graph.getNodes().size());
            meanColors = new SMAdoubleVariable(graph.getNodes().size());
            meanNeighbors = new SMAdoubleVariable(graph.getNodes().size());
            meanThroughput = new SMAdoubleVariable(graph.getNodes().size());
            meanDelay = new SMAdoubleVariable(graph.getNodes().size());

            Collections.sort(graph.getNodes(), new NodeComparator("DESC"));

            for (Node node : graph.getNodes()) {
                meanAttempts.addMeasurement(node.getSmaAttempts().getMean());
                meanSuccesses.addMeasurement(node.getSmaSuccesses().getMean());
                meanCollisions.addMeasurement(node.getSmaCollisions().getMean());

                meanColors.addMeasurement(node.getMaxColors());
                meanNeighbors.addMeasurement(node.countNeighbors());
                meanThroughput.addMeasurement(node.getSmaThroughput().getMean());
                meanDelay.addMeasurement(node.getSmaDelay().getMean());

                if (nodeWise) //node-wise
                {
                    if (node.getId() == 9) { //arbitrarily chosen node
                        out1.println(timeSlotId
                                + "," + node.getMaxColors()
                                + "," + node.countNeighbors()
                                + "," + df.format(new Double(node.getSmaSuccesses().getSum()) / new Double(node.getSmaAttempts().getSum()))
                                + "," + df.format(new Double(node.getSmaCollisions().getSum()) / new Double(node.getSmaAttempts().getSum()))
                                + "," + df.format(node.getSmaThroughput().getMean())
                                + "," + df.format(node.getSmaDelay().getMean()));
                    }
                }
            } //for

            successOverAttempt = new Double(meanSuccesses.getSum()) / new Double(meanAttempts.getSum());
            collisionPercentage = new Double(meanCollisions.getSum()) / new Double(meanAttempts.getSum());
            S2 = new Double(meanThroughput.getMean());

            if (graphWise) { //graph-wise
            	out1.println(timeSlotId
                        + "," + meanColors.toString()
                        + "," + meanNeighbors.toString()
                        + "," + df.format(successOverAttempt)
                        + "," + df.format(collisionPercentage)
                        + "," + df.format(S2)
                        + "," + df.format(meanDelay.getMean()));
            	//out1.println(df.format(S2));
            }
        } //for

        if (meanIterationWise) { //(mean-iterations)-wise
            out1.println(sigma
                + "," + meanColors.toString()
                + "," + meanNeighbors.toString()
                + "," + df.format(successOverAttempt)
                + "," + df.format(collisionPercentage)
                + "," + df.format(S2)
                + "," + df.format(meanDelay.getMean()));
        }
        if (out1 != System.out) out1.close();
    }

    public static void main(String[] args) {

        ArrayList<String> graphFilenames = new ArrayList<String>();
        //0  1   2
        graphFilenames.add("graph250-10.graph");
        graphFilenames.add("graph250-50.graph");
        graphFilenames.add("graph250-90.graph");
        //3  4   5
        graphFilenames.add("graph500-10.graph");
        graphFilenames.add("graph500-50.graph");
        graphFilenames.add("graph500-90.graph");
        //6  7   8
        graphFilenames.add("graph1000-10.graph");
        graphFilenames.add("graph1000-50.graph");
        graphFilenames.add("graph1000-90.graph");
        //9  10  11
        graphFilenames.add("graph1.graph");
        graphFilenames.add("graph010-30.graph");
        graphFilenames.add("graph010-50.graph");

        //Initial parameters
        //int TIMESLOTS = 1000; //100000 in the colorwave paper
        //int MAX_COLORS = 3; //3, 4, 6, 8, 10, 12 in colorwave paper
        //double P = 0.9; //transmission probability p: 0.05, 0.25, 0.50, 0.75 and 1.0 in colorwave paper
        //int MIN_TIME_IN_COLOR = 10;
        final String measurementsDir = "C:/Users/nkons/Desktop/";

        if (nodeWise) {
           System.out.println("timeSlotId,maxColors,countNeighbors,successOverAttempt,collisionsOverAttempts,meanThroughput,meanDelay");
           Simulation simulation01 = new Simulation(graphFilenames.get(0), 25000, 12, 0.30, 50, DCS, measurementsDir + "dcs.csv");
        }
        
        if (graphWise) {
            //System.out.println("timeSlotId,meanColors,meanNeighbors,successOverAttempt,collisionPercentage,Throughput(S2),meanDelay");
//            System.out.println("1");
//            Simulation simulation01 = new Simulation(graphFilenames.get(2), 50000, 12, 0.30, 50, DCS, measurementsDir + "graph250-90-dcs30.csv");
//            System.out.println("2");
//            Simulation simulation02 = new Simulation(graphFilenames.get(2), 50000, 12, 0.30, 50, COLORWAVE, measurementsDir + "graph250-90-colorwave30.csv");
//            System.out.println("3");
//            Simulation simulation03 = new Simulation(graphFilenames.get(2), 50000, 12, 0.30, 50, EXPOWAVE, measurementsDir + "graph250-90-expowave30.csv");
//
//            System.out.println("4");
//            Simulation simulation04 = new Simulation(graphFilenames.get(2), 50000, 12, 0.60, 50, DCS, measurementsDir + "graph250-90-dcs60.csv");
//            System.out.println("5");
//            Simulation simulation05 = new Simulation(graphFilenames.get(2), 50000, 12, 0.60, 50, COLORWAVE, measurementsDir + "graph250-90-colorwave60.csv");
//            System.out.println("6");
//            Simulation simulation06 = new Simulation(graphFilenames.get(2), 50000, 12, 0.60, 50, EXPOWAVE, measurementsDir + "graph250-90-expowave60.csv");
//
//            System.out.println("7");
//            Simulation simulation07 = new Simulation(graphFilenames.get(2), 50000, 12, 0.90, 50, DCS, measurementsDir + "graph250-90-dcs90.csv");
//            System.out.println("8");
            Simulation simulation08 = new Simulation(graphFilenames.get(1), 100000, 12, 0.89, 25, COLORWAVE, measurementsDir + "graph250-50-colorwave90.csv");
//            System.out.println("9");
//            Simulation simulation09 = new Simulation(graphFilenames.get(2), 50000, 12, 0.90, 50, EXPOWAVE, measurementsDir + "graph250-90-expowave90.csv");

            System.out.println("done.");
        }

        if (meanIterationWise) {

            
            System.out.println("DCS in " + graphFilenames.get(0));
            System.out.println("sigma,meanColors,meanNeighbors,successOverAttempt,collisionPercentage,Throughput(S2),meanDelay");
            for (int i = 1; i < 100; i++) {
                Simulation simulation = new Simulation(graphFilenames.get(0), 25000, 12, new Double(i) / 100, 50, DCS, null);
            }

            System.out.println("Colorwave in " + graphFilenames.get(0));
        	System.out.println("sigma,meanColors,meanNeighbors,successOverAttempt,collisionPercentage,Throughput(S2),meanDelay");
            for (int i = 1; i < 100; i++) {
                Simulation simulation = new Simulation(graphFilenames.get(0), 25000, 12, new Double(i) / 100, 50, COLORWAVE, null);
            }

            System.out.println("Expowave in " + graphFilenames.get(0));
        	System.out.println("sigma,meanColors,meanNeighbors,successOverAttempt,collisionPercentage,Throughput(S2),meanDelay");
            for (int i = 1; i < 100; i++) {
                Simulation simulation = new Simulation(graphFilenames.get(0), 25000, 12, new Double(i) / 100, 50, EXPOWAVE, null);
            }

            //
            System.out.println("DCS in " + graphFilenames.get(1));
            System.out.println("sigma,meanColors,meanNeighbors,successOverAttempt,collisionPercentage,Throughput(S2),meanDelay");
            for (int i = 1; i < 100; i++) {
                Simulation simulation = new Simulation(graphFilenames.get(1), 25000, 12, new Double(i) / 100, 50, DCS, null);
            }

            System.out.println("Colorwave in " + graphFilenames.get(1));
            System.out.println("sigma,meanColors,meanNeighbors,successOverAttempt,collisionPercentage,Throughput(S2),meanDelay");
            for (int i = 1; i < 100; i++) {
                Simulation simulation = new Simulation(graphFilenames.get(1), 25000, 12, new Double(i) / 100, 50, COLORWAVE, null);
            }

            System.out.println("Expowave in " + graphFilenames.get(1));
            System.out.println("sigma,meanColors,meanNeighbors,successOverAttempt,collisionPercentage,Throughput(S2),meanDelay");
            for (int i = 1; i < 100; i++) {
                Simulation simulation = new Simulation(graphFilenames.get(1), 25000, 12, new Double(i) / 100, 50, EXPOWAVE, null);
            }
            
            //
            System.out.println("DCS in " + graphFilenames.get(2));
            System.out.println("sigma,meanColors,meanNeighbors,successOverAttempt,collisionPercentage,Throughput(S2),meanDelay");
            for (int i = 1; i < 100; i++) {
                Simulation simulation = new Simulation(graphFilenames.get(2), 25000, 12, new Double(i) / 100, 50, DCS, null);
            }

            System.out.println("Colorwave in " + graphFilenames.get(2));
            System.out.println("sigma,meanColors,meanNeighbors,successOverAttempt,collisionPercentage,Throughput(S2),meanDelay");
            for (int i = 40; i < 100; i++) {
                Simulation simulation = new Simulation(graphFilenames.get(2), 25000, 12, new Double(i) / 100, 50, COLORWAVE, null);
            }

            System.out.println("Expowave in " + graphFilenames.get(2));
            System.out.println("sigma,meanColors,meanNeighbors,successOverAttempt,collisionPercentage,Throughput(S2),meanDelay");
            for (int i = 1; i < 100; i++) {
                Simulation simulation = new Simulation(graphFilenames.get(2), 25000, 12, new Double(i) / 100, 50, EXPOWAVE, null);
            }

            System.out.println("done.");
        }
    } //main

    public Graph createGraph(String filename, int maxColors, double sigma, int minTimeInColor, int algorithm) {

        int lineCount = 0;
        int rowCount = 0;

        Graph graph = new Graph();

        Node[] nodes;

        try {
            File f = new File(filename);
            //if (verbose) System.out.println(f.getAbsolutePath());
            FileInputStream in = new FileInputStream(f.getAbsolutePath());
            BufferedReader br = new BufferedReader(new InputStreamReader(in));

            String line = "";


            while ((line = br.readLine()) != null) {
                lineCount++;
                if (rowCount == 0) {
                    rowCount = line.length();
                }
            }

            //allocate space for the node table
            nodes = new Node[lineCount];

            for (int i = 0; i < lineCount; i++) {

                nodes[i] = new Node(i, maxColors, sigma, minTimeInColor, algorithm); // <------- Configure
                nodes[i].setStatus(nodes[i].IDLE);
                if (maxColors == 0) {
                    maxColors = nodes[i].maxColors;
                }
            }
            //now assign a color timeslot to each one
            assignColors(nodes);

            line = "";

            FileInputStream in2 = new FileInputStream(f.getAbsolutePath());
            BufferedReader br2 = new BufferedReader(new InputStreamReader(in2));
            int currentLineCount = 0;
            while ((line = br2.readLine()) != null) {
                currentLineCount++;
                for (int i = 0; i < line.length(); i++) {
                    char c = line.charAt(i);
                    if (c == '1') {
                        nodes[currentLineCount - 1].addNeighbor(nodes[i]); // = 1;
                    }
                }
            }

            //Store the whole graph
            for (int i = 0; i < nodes.length; i++) {
                graph.addNode(nodes[i]);
            }

            //if (verbose) System.out.println("graph has " + graph.getNodes().size() + " nodes");

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return graph;
    }

    void assignColors(Node[] nodes) {
        int currentColor = 0;
        for (int currentNode = 0; currentNode < nodes.length; currentNode++) {
            nodes[currentNode].setColor(currentColor);
            if (currentColor < nodes[currentNode].maxColors - 1) {
                currentColor++;
            } else {
                currentColor = 0;
            }
        }
    }

//	private long countSeconds() {
//		Calendar c = Calendar.getInstance();
//		return c.getTimeInMillis();
//	}
    public int getAttempts() {
        return attempts;
    }

    public void setAttempts(int attempts) {
        this.attempts = attempts;
    }

    public int getSuccesses() {
        return successes;
    }

    public void setSuccesses(int successes) {
        this.successes = successes;
    }

    public int getCollisions() {
        return collisions;
    }

    public void setCollisions(int collisions) {
        this.collisions = collisions;
    }
}
