package com.expowave.graph;

import java.util.ArrayList;

public class Graph {

    private ArrayList<Node> nodes = new ArrayList<Node>();

    public Graph() {
    }

    public Node findNodeById(int id) {
        for (Node node : nodes) {
            if (node.getId() == id) {
                return node;
            }
        }
        return null;
    }

    public void addNode(Node node) {
        nodes.add(node);
    }

    public ArrayList<Node> getNodes() {
        return nodes;
    }

    public void setNodes(ArrayList<Node> nodes) {
        this.nodes = nodes;
    }
}
