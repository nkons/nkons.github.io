package com.expowave.graph;

import com.expowave.util.SMAdoubleVariable;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class Node {

    DecimalFormat df = new DecimalFormat("####.###");
    public final int IDLE = 0;
    public final int TRANSMITTING = 1;
    public final int COLLIDE = 2;
    public final int WINDOW_SIZE = 500;
    
    public int COLOR_UPPER_BOUND = 30;

    public final int DCS = 101;
    public final int COLORWAVE = 102;
    public final int EXPOWAVE = 103;
    
    public boolean verbose = false;
    
    //allowed values 0, ..., n-1. Values 3, 4, 6, 8, 10, 12 in colorwave paper
    public int maxColors;
    
    //transmission (birth) probability p: 0.05, 0.25, 0.50, 0.75 and 1.0 in colorwave paper
    public double sigma;
    private int id;
    private int status;
    private int color;
    private int algorithm;
    private ArrayList<Node> neighbors = new ArrayList<Node>();

    private int timeSlotId;
    //private int timeSlotType;
    //for how many timeslots the node will be in collision
    //For how many timeslots a tag will have to be in the reader's vicinity in order
    //to be recognized or in other words for how many timeslots the node will be in collision
    //public int timeSlotsWaited = 0;
    //public SMAdoubleVariable smaTimeSlotsWaited = new SMAdoubleVariable(WINDOW_SIZE);
    public int successes = 0; //<--- Moving average
    public int attempts = 0; //<--- Moving average
    public int collisions = 0; //<--- Moving average
    public int timeInMaxColors = 0;
    public boolean changedMaxColors;
    //Colorwave variables
    //the trigger percentage at which to increase max colors if a neighboring reader
    //is also switching to a max colors higher than that of this reader.
    //0.90 in colorwave paper
    double upTrig = 0.90;
    //the safe percentage at which to increase max colors
    //0.93 in colorwave paper
    double upSafe = 0.93;
    //analogous to upSafe, upTrig, except decreasing max colors.
    double dnTrig = 0.99; //0.99 in colorwave paper
    double dnSafe = 0.98; //0.98 in colorwave paper
    //the minimum number of timeslots before the Colorwave algorithm will change
    //maxColors again after initialization or changing maxColors.
    int minTimeInMaxColors; //100, 500 and 1000 in colorwave paper
    //End Colorwave variables
    
    boolean limitColors = true;
    public int waiting = 0;
    public int currentAttempts = 0;
    public SMAdoubleVariable smaSuccesses = new SMAdoubleVariable(WINDOW_SIZE);
    public SMAdoubleVariable smaAttempts = new SMAdoubleVariable(WINDOW_SIZE);
    public SMAdoubleVariable smaCollisions = new SMAdoubleVariable(WINDOW_SIZE);
    public SMAdoubleVariable smaDelay = new SMAdoubleVariable(WINDOW_SIZE);
    public SMAdoubleVariable smaThroughput = new SMAdoubleVariable(WINDOW_SIZE);

    public Node(int id, int maxColors, double sigma, int minTimeInMaxColors, int algorithm) {
        this.id = id;

        attempts = 0;
        successes = 0;
        collisions = 0;
        
        this.maxColors = maxColors;
        this.sigma = sigma;
        this.minTimeInMaxColors = minTimeInMaxColors;
        this.algorithm = algorithm;

        limitColors = true; //(algorithm == DCS) || (algorithm == EXPOWAVE);

        changedMaxColors = false;
    }

    public void requestTransmission(int timeSlotId) {

        if (((algorithm == EXPOWAVE) && (waiting == 0 || waiting == -1)) || (algorithm != EXPOWAVE)) {

            attempts++;
            smaAttempts.addMeasurement(1);

            status = TRANSMITTING;

            if (verbose) {
                System.out.print("node " + getId() + " requesting transmission for timeslotid " + timeSlotId + " (color " + getColor() + ")");
            }

            int collidingNode = 0;
            for (int i = 0; i < neighbors.size(); i++) {
                if (neighbors.get(i).getStatus() == TRANSMITTING && neighbors.get(i).getColor() == getColor()) {
                    status = COLLIDE;
                    collidingNode = i;
                }
            }

            if (status == COLLIDE) {
                collisions++;
                smaCollisions.addMeasurement(1);
                smaDelay.addMeasurement(1);
                smaSuccesses.addMeasurement(0);

                if (verbose) {
                    System.out.println(". collision with node " + neighbors.get(collidingNode).getId() + " (node " + neighbors.get(collidingNode).getId() + " color is " + neighbors.get(collidingNode).getColor() + " and status is " + neighbors.get(collidingNode).getStatus() + ")");
                }

                if (algorithm != DCS) {
                    changeMaxColors();
                }

                if (algorithm == EXPOWAVE) {
                    //Exponential Backoff
                    waiting = new Double(Math.random() * (Math.pow(2, currentAttempts++) - 1)).intValue(); //1
                } // else {
                  //  //Linear Backoff
                  //  waiting = new Double(Math.random() * (currentAttempts++ - 1)).intValue();
                //}

                kick();
            }

            if (status != COLLIDE) {
                if (verbose) {
                    System.out.println(". success");
                }
                successes++;
                smaSuccesses.addMeasurement(1);
                smaCollisions.addMeasurement(0);
                smaDelay.addMeasurement(0);

                waiting = 0;
                currentAttempts = 0; //attempts till a transmission is succeeded
            }
            smaThroughput.addMeasurement(smaSuccesses.getMean());

            if (verbose) {
                System.out.println("   status for node " + getId() + " is now " + getStatus());
            }
        } else {
            if (algorithm == EXPOWAVE) {
                smaAttempts.addMeasurement(0);
                smaDelay.addMeasurement(1);
                waiting--;
            }
        }
    }

    public void kick() {
        changeOwnColorToRandom();
        broadcastKick(color, neighbors);
    }

    public void broadcastKick(int color, ArrayList<Node> nodes) {
        for (Node node : nodes) {
            if (node.getColor() == color) {
                changeColor(node);
            }
        }
    }

    public void changeOwnColorToRandom() {
        int oldColor = color;
        if (verbose) {
            System.out.print("kick: node " + id + " kicking new color from " + oldColor + " to ");
        }

        ArrayList<Integer> allowedColors = new ArrayList<Integer>();
        for (int i = 0; i < maxColors; i++) {
            if (i != color) {
                allowedColors.add(i);
            }
        }

        int newColor = allowedColors.get(new Double(allowedColors.size() * Math.random()).intValue());

        color = newColor;

        if (verbose) {
            System.out.println(color + " and notifying neighbors");
        }
    }

    public void changeMaxColors() {
        int oldMaxColors = maxColors;
        boolean caseUp = cp() > upSafe || (cp() > upTrig && findNeighborWithHigherMaxColors());
        boolean caseDn = (cp() < dnSafe || (cp() < dnTrig && findNeighborWithHigherMaxColors())) && maxColors > 2;
        if (!changedMaxColors && (caseUp || caseDn) && (timeInMaxColors > minTimeInMaxColors)) {

            if (caseUp) {
                if ((limitColors && maxColors < COLOR_UPPER_BOUND) || !limitColors) {
                    maxColors++;
                }
            } else if (caseDn) {
                maxColors--;
            }
            changedMaxColors = true;
            timeInMaxColors = 0;

            if (verbose) {
                System.out.println("TimeInMaxColors is set to 0 for node " + id + " after staying in this color for " + minTimeInMaxColors + " timeslots");
            }

            int newMaxColors = maxColors;

            if (newMaxColors != oldMaxColors) {
                if (verbose) {
                    System.out.println("Node " + id + " changed maxColors from " + oldMaxColors + " to " + newMaxColors + ". collisionPercentage " + cp());
                }

                broadcastChangeMaxColors(neighbors, caseUp);
            }
        }
    }

    //uptrig (90) should be < upsafe (93) and dntrig (99) should be > dnsafe (98)
    public boolean findNeighborWithHigherMaxColors() {
        for (Node node : neighbors) {
            if (node.getMaxColors() > maxColors) {
                return true;
            }
        }
        return false;
    }

    public void broadcastChangeMaxColors(ArrayList<Node> nodes, boolean increase) {
        for (Node node : nodes) {
            //if (node.cp() > node.upTrig && node.timeInColor > node.minTimeInColor) {
            if (!node.isChangedMaxColors() && (node.getTimeInMaxColors() > node.getMinTimeInMaxColors())) {

                int newMaxColors = node.getMaxColors();
                if (increase && ((limitColors && node.getMaxColors() < COLOR_UPPER_BOUND) || !limitColors)) { // && (node.cp() > node.upTrig)) {
                    newMaxColors = node.getMaxColors() + 1;
                } else if (node.getMaxColors() > 2) { //(node.cp() < node.dnTrig) &&
                    newMaxColors = node.getMaxColors() - 1;
                }

                if (verbose) {
                    System.out.println("   Broadcast color change: Node " + id + " requested change maxColors on node " + node.getId()
                            + " from " + node.getMaxColors() + " to " + newMaxColors);
                }

                node.setMaxColors(newMaxColors);
                node.setChangedMaxColors(true);
                node.setTimeInMaxColors(0); // or 0 so as to have 0 in the next timeslot?
            }
        }
    }

    //collisionPercentage
    public double cp() {
        //With running average statistics
        if (attempts == 0) {
            return new Double(0);
        } else {
            Double collisions = new Double(getSmaCollisions().getSum());
            Double attempts = new Double(getSmaAttempts().getSum());
            if (collisions > 0 && attempts > 0) {
                Double collisionPercentage = collisions / attempts;

                return collisionPercentage.doubleValue();
            } else {
                return new Double(0);
            }
        }
    }

    public void addNeighbor(Node neighborNode) {
        this.neighbors.add(neighborNode);
    }

    public int countNeighbors() {
        return neighbors.size();
    }

    public void changeColor(Node node) {

        ArrayList<Integer> allowedColors = new ArrayList<Integer>();
        for (int i = 0; i < node.getMaxColors(); i++) {
            if (i != node.getColor()) {
                allowedColors.add(i);
            }
        }

        int newColor = allowedColors.get(new Double(allowedColors.size() * Math.random()).intValue());

        if (verbose) {
            System.out.print("   broadcastKick: Node " + node.getId() + " changes color from " + node.getColor() + " ");
        }
        node.setColor(newColor);

        if (verbose) {
            System.out.println(" to " + node.getColor());
        }
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getColor() {
        return color;
    }

    public void setColor(int color) {
        this.color = color;
    }

    public int getAlgorithm() {
		return algorithm;
	}
    public void setAlgorithm(int algorithm) {
		this.algorithm = algorithm;
	}
    
    public int getMaxColors() {
        return maxColors;
    }

    public void setMaxColors(int maxColors) {
        this.maxColors = maxColors;
    }

    public List<Node> getNeighbors() {
        return neighbors;
    }

    public void setNeighbors(ArrayList<Node> neighbors) {
        this.neighbors = neighbors;
    }

    public int getTimeSlotId() {
        return timeSlotId;
    }

    public void setTimeSlotId(int timeSlotId) {
        this.timeSlotId = timeSlotId;
    }

    public double getSigma() {
        return sigma;
    }

    public void setSigma(double sigma) {
        this.sigma = sigma;
    }

    public int getAttempts() {
        return attempts;
    }

    public void setAttempts(int attempts) {
        this.attempts = attempts;
    }

    public int getSuccesses() {
        return successes;
    }

    public void setSuccesses(int successes) {
        this.successes = successes;
    }

    public int getCollisions() {
        return collisions;
    }

    public void setCollisions(int collisions) {
        this.collisions = collisions;
    }

    public int getMinTimeInMaxColors() {
        return minTimeInMaxColors;
    }

    public void setMinTimeInMaxColors(int minTimeInMaxColors) {
        this.minTimeInMaxColors = minTimeInMaxColors;
    }

    public int getTimeInMaxColors() {
        return timeInMaxColors;
    }

    public void setTimeInMaxColors(int timeInMaxColors) {
        this.timeInMaxColors = timeInMaxColors;
    }

    public int getWaiting() {
        return waiting;
    }

    public void setWaiting(int waiting) {
        this.waiting = waiting;
    }

    public SMAdoubleVariable getSmaAttempts() {
        return smaAttempts;
    }

    public void setSmaAttempts(SMAdoubleVariable smaAttempts) {
        this.smaAttempts = smaAttempts;
    }

    public SMAdoubleVariable getSmaSuccesses() {
        return smaSuccesses;
    }

    public void setSmaSuccesses(SMAdoubleVariable smaSuccesses) {
        this.smaSuccesses = smaSuccesses;
    }

    public SMAdoubleVariable getSmaCollisions() {
        return smaCollisions;
    }

    public void setSmaCollisions(SMAdoubleVariable smaCollisions) {
        this.smaCollisions = smaCollisions;
    }

    public SMAdoubleVariable getSmaThroughput() {
        return smaThroughput;
    }

    public void setSmaThroughput(SMAdoubleVariable smaThroughput) {
        this.smaThroughput = smaThroughput;
    }

    public SMAdoubleVariable getSmaDelay() {
        return smaDelay;
    }

    public void setSmaDelay(SMAdoubleVariable smaDelay) {
        this.smaDelay = smaDelay;
    }

    public boolean isChangedMaxColors() {
        return changedMaxColors;
    }

    public void setChangedMaxColors(boolean changedMaxColors) {
        this.changedMaxColors = changedMaxColors;
    }

    public double getUpSafe() {
        return upSafe;
    }

    public void setUpSafe(double upSafe) {
        this.upSafe = upSafe;
    }

    public double getUpTrig() {
        return upTrig;
    }

    public void setUpTrig(double upTrig) {
        this.upTrig = upTrig;
    }

    public double getDnSafe() {
        return dnSafe;
    }

    public void setDnSafe(double dnSafe) {
        this.dnSafe = dnSafe;
    }

    public double getDnTrig() {
        return dnTrig;
    }

    public void setDnTrig(double dnTrig) {
        this.dnTrig = dnTrig;
    }
}
