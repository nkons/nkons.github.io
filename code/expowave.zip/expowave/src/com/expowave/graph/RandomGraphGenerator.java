package com.expowave.graph;

public class RandomGraphGenerator {

	public RandomGraphGenerator() {
		int MAX = 1000;

		int[][] c = new int[MAX][MAX];
		
		for (int i = 0; i < MAX; i++) {
			for (int j = 0; j < MAX; j++) {
				if (i < j) {
					double d = Math.random();
					if (d < 0.9) {
						c[i][j] = 1;
					} else {
						c[i][j] = 0;
					}
				} else {
					if (i == j) {
						c[i][j] = 0;
					} else {
						c[i][j] = c[j][i];
					}
				}
			}
		}
		
		for (int i = 0; i < MAX; i++) {
			for (int j = 0; j < MAX; j++) {
				System.out.print(c[i][j]);
			}
			System.out.println();
		}
		
	}
	
	public static void main(String[] args) {
		RandomGraphGenerator rgg = new RandomGraphGenerator();
	}
}
