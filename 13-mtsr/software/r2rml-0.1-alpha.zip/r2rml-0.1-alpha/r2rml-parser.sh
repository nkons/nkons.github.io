echo "This is R2RML Parser"

java -cp "./*;./lib/*;" gr.ekt.r2rml.beans.Main